<?php

namespace App\Http\Controllers;

use App\Models\Categories;
use App\Models\Product;
use Illuminate\Http\Request;

class WebController extends Controller
{
    public function index()
    {
        $categories = Categories::where('active', 1)->limit(10)->get();
        //dd($categories);
        return view('/web/pages/index',compact('categories'));
    }

    public function aboutus()
    {
        return view('/web/pages/aboutus');
    }

    public function clients()
    {
        return view('/web/pages/clients');
    }

    public function export()
    {
        return view('/web/pages/export');
    }

    public function category()
    {
        $categories = Categories::where('active', 1)->get();
        return view('/web/pages/category',compact('categories'));
    }

    public function product($slug)
    {
        $categories = Categories::where('slug', $slug)->get();
        $products = Product::where('category_id', $categories[0]->id)->get();

        return view('/web/pages/product',['products'=>$products]);
    }
    public  function product_details($slug)
    {
        //$products = Product::where('slug', $slug)->get();

        $products = Product::with('category')->with('images')->where('slug', $slug)->first();
        dd($products->images[0]->image_url);
        return view('/web/pages/product-details',['products'=>$products]);
    }

    public function production()
    {
        return view('/web/pages/production');
    }

    public function contactus()
    {
        return view('/web/pages/contactus');
    }

    public function privacypolicy()
    {
        return view('/web/pages/privacypolicy');
    }

    public function termsandcondition()
    {
        return view('/web/pages/termsandcondition');
    }

    public function shippingandreturn()
    {
        return view('/web/pages/shippingandreturn');
    }
}
